#include "FT_hostEmul.h"
#include "FtTask.h"
#include <QTimer>
#include <qvalidator.h>

FT_hostEmul::FT_hostEmul(QWidget *parent)
    : QMainWindow(parent), m_ftTask(nullptr)
{
    ui.setupUi(this);
	m_ftTask = new FtTask();
	m_ftTask->start();

	QIntValidator *validator = new QIntValidator(0, 29, this);
	ui.lineEdit->setValidator(validator);
	QRegExp regExp("[a-fA-F0-9]{4}");
	ui.lineEdit_2->setValidator(new QRegExpValidator(regExp, this));
	connect(ui.pushButton, &QPushButton::clicked, this, &FT_hostEmul::onBtnWrite);
	connect(ui.pushButton_2, &QPushButton::clicked, this, &FT_hostEmul::onBtnClearAll);
}

FT_hostEmul::~FT_hostEmul()
{
	delete m_ftTask;
	m_ftTask = nullptr;
}

void FT_hostEmul::onBtnWrite()
{
	if (ui.lineEdit->text().isEmpty()) {
		return;
	}
	if (ui.lineEdit_2->text().isEmpty()) {
		return;
	}
	int index = ui.lineEdit->text().toInt();
	QString hex_str = "0x"+ui.lineEdit_2->text();
	unsigned char data = hex_str.toUInt(nullptr, 16);
	m_ftTask->setBuff(index, data);
	m_ftTask->update();
}

void FT_hostEmul::onBtnClearAll()
{
	m_ftTask->clearBuff();
	m_ftTask->update();
}
