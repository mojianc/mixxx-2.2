#include "FT_hostEmul.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    FT_hostEmul w;
    w.show();
    return a.exec();
}
