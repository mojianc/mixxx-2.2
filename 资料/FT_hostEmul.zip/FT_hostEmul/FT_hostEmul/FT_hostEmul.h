#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_FT_hostEmul.h"

class FtTask;
class FT_hostEmul : public QMainWindow
{
    Q_OBJECT

public:
    FT_hostEmul(QWidget *parent = Q_NULLPTR);
	~FT_hostEmul();
public slots:

	void onBtnWrite();
	void onBtnClearAll();
private:
    Ui::FT_hostEmulClass ui;
	FtTask* m_ftTask;
};
