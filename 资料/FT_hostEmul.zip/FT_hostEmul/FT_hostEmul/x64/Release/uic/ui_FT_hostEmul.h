/********************************************************************************
** Form generated from reading UI file 'FT_hostEmul.ui'
**
** Created by: Qt User Interface Compiler version 5.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FT_HOSTEMUL_H
#define UI_FT_HOSTEMUL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FT_hostEmulClass
{
public:
    QWidget *centralWidget;
    QLineEdit *lineEdit;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton;
    QFrame *line;
    QPushButton *pushButton_2;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *FT_hostEmulClass)
    {
        if (FT_hostEmulClass->objectName().isEmpty())
            FT_hostEmulClass->setObjectName(QStringLiteral("FT_hostEmulClass"));
        FT_hostEmulClass->resize(600, 400);
        centralWidget = new QWidget(FT_hostEmulClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        lineEdit = new QLineEdit(centralWidget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(130, 40, 113, 21));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(30, 40, 72, 21));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(30, 100, 72, 21));
        lineEdit_2 = new QLineEdit(centralWidget);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(130, 100, 113, 21));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(330, 96, 93, 28));
        line = new QFrame(centralWidget);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(0, 150, 591, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(330, 210, 93, 28));
        FT_hostEmulClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(FT_hostEmulClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 600, 26));
        FT_hostEmulClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(FT_hostEmulClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        FT_hostEmulClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(FT_hostEmulClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        FT_hostEmulClass->setStatusBar(statusBar);

        retranslateUi(FT_hostEmulClass);

        QMetaObject::connectSlotsByName(FT_hostEmulClass);
    } // setupUi

    void retranslateUi(QMainWindow *FT_hostEmulClass)
    {
        FT_hostEmulClass->setWindowTitle(QApplication::translate("FT_hostEmulClass", "FT_hostEmul", Q_NULLPTR));
        label->setText(QApplication::translate("FT_hostEmulClass", "\345\272\217\345\217\267\357\274\232", Q_NULLPTR));
        label_2->setText(QApplication::translate("FT_hostEmulClass", "\345\200\274  \357\274\232", Q_NULLPTR));
        pushButton->setText(QApplication::translate("FT_hostEmulClass", "\345\206\231\345\205\245", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("FT_hostEmulClass", "\346\270\205\345\261\217", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class FT_hostEmulClass: public Ui_FT_hostEmulClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FT_HOSTEMUL_H
